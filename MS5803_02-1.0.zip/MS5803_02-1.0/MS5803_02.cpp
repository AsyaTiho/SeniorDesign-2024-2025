#include "MS5803_02.h"
#include <Wire.h>

// For I2C, set the CSB Pin (pin 3) high for address 0x76, and pull low
// for address 0x77. If you use 0x77, change the value on the line below:
#define MS5803_I2C_ADDRESS    0x76
#define CMD_RESET       0x1E    // ADC reset command
#define CMD_ADC_READ    0x00    // ADC read command
#define CMD_ADC_CONV    0x40    // ADC conversion command
#define CMD_ADC_D1      0x00    // ADC D1 conversion
#define CMD_ADC_D2      0x10    // ADC D2 conversion
#define CMD_ADC_256     0x00    // ADC resolution=256
#define CMD_ADC_512     0x02    // ADC resolution=512
#define CMD_ADC_1024    0x04
#define CMD_ADC_2048    0x06
#define CMD_ADC_4096    0x08

static unsigned int sensorCoeffs[8];
static uint32_t D1 = 0;
static uint32_t D2 = 0;
static int32_t dT = 0;
static int32_t TEMP = 0;
static int64_t Offset = 0;
static int64_t Sensitivity  = 0;
static int64_t T2 = 0;
static int64_t OFF2 = 0;
static int64_t Sens2 = 0;
static byte HighByte;
static byte MidByte;
static byte LowByte;

//-------------------------------------------------
// Constructor
MS_5803::MS_5803(uint16_t Resolution) {
    _Resolution = Resolution;
    // Note: No Wire.begin() here - it should be called in the main sketch
}

//-------------------------------------------------
boolean MS_5803::initializeMS_5803(boolean Verbose) {
    // Note: Wire.begin() is NOT called here anymore
    // The main sketch should initialize the I2C bus before using this library
    
    // Reset the sensor (not the I2C bus)
    resetSensor();
    delay(10);

    if (Verbose) {
        if (_Resolution == 256 || _Resolution == 512 || _Resolution == 1024 ||
            _Resolution == 2048 || _Resolution == 4096) {
            // Serial.print("Oversampling setting: ");
            // Serial.println(_Resolution);
        } else {
            // Serial.println("Error: Invalid oversampling value!");
            return false;
        }
        // Serial.println("Checking PROM Calibration Data...");
    }

    // Read calibration coefficients
    for (int i = 0; i < 8; i++) {
        int retry_count = 0;
        bool success = false;

        while (retry_count < 3 && !success) {
            Wire.beginTransmission(MS5803_I2C_ADDRESS);
            Wire.write(0xA0 + (i * 2));  
            byte result = Wire.endTransmission();
            
            if (result != 0) {  
                // Serial.print("I2C Transmission Failed at PROM Register: 0x");
                // Serial.println(0xA0 + (i * 2), HEX);
                retry_count++;
                delay(10);
                continue;
            }

            delay(10);

            byte bytesRequested = 2;
            byte bytesReceived = Wire.requestFrom(MS5803_I2C_ADDRESS, bytesRequested);
            
            if (bytesReceived == bytesRequested) {
                HighByte = Wire.read();
                LowByte = Wire.read();
                sensorCoeffs[i] = (((unsigned int)HighByte << 8) + LowByte);

                if (sensorCoeffs[i] == 0 && i > 0 && i < 7) {
                    retry_count++;
                    delay(10);
                } else {
                    success = true;
                }
            } else {
                // Serial.print("PROM Read Error at C");
                // Serial.println(i);
                
                // Clear the I2C buffer
                while (Wire.available()) {
                    Wire.read();
                }
                
                retry_count++;
                delay(10);
            }
        }
        // Optional: comment out to hide
        // Serial.print("C");
        // Serial.print(i);
        // Serial.print(": ");
        // Serial.println(sensorCoeffs[i]);
    }

    // Check if coefficients are valid
    if (sensorCoeffs[1] == 0 || sensorCoeffs[2] == 0 ||
        sensorCoeffs[3] == 0 || sensorCoeffs[4] == 0) {
        // Serial.println("ERROR: Calibration coefficients are all 0! Check sensor wiring.");
        return false;
    }

    // Serial.println("PROM Calibration Data Read Successfully.");

    // Check CRC
    unsigned char p_crc = sensorCoeffs[7] & 0x0F;
    unsigned char n_crc = MS_5803_CRC(sensorCoeffs);
    if (Verbose) {
        // Serial.print("p_crc: ");
        // Serial.println(p_crc);
        // Serial.print("n_crc: ");
        // Serial.println(n_crc);
    }
    if (p_crc != n_crc) {
        // Serial.println("⚠ WARNING: CRC ERROR, but continuing initialization...");
        return true;
    }

    // Serial.println("MS5803 Successfully Initialized!");
    return true;
}

//------------------------------------------------------------------
void MS_5803::readSensor() {
    // Acquire raw data from sensor
    byte adcCommand = 0;
    
    if (_Resolution == 256) {
        adcCommand = CMD_ADC_256;
    } else if (_Resolution == 512) {
        adcCommand = CMD_ADC_512;
    } else if (_Resolution == 1024) {
        adcCommand = CMD_ADC_1024;
    } else if (_Resolution == 2048) {
        adcCommand = CMD_ADC_2048;
    } else if (_Resolution == 4096) {
        adcCommand = CMD_ADC_4096;
    }
    
    // Read pressure with retry
    for (int retry = 0; retry < 3; retry++) {
        D1 = MS_5803_ADC(CMD_ADC_D1 + adcCommand);
        if (D1 != 0) break;
        delay(5);
    }
    
    // Read temperature with retry
    for (int retry = 0; retry < 3; retry++) {
        D2 = MS_5803_ADC(CMD_ADC_D2 + adcCommand);
        if (D2 != 0) break;
        delay(5);
    }

    // *** Commented out debug prints ***
    // Serial.print("D1 (Raw Pressure ADC): ");
    // Serial.println(D1);
    // Serial.print("D2 (Raw Temperature ADC): ");
    // Serial.println(D2);

    // Calculate temperature difference
    dT = (int32_t)D2 - ((int32_t)sensorCoeffs[5] * 256);

    // Compute actual temperature
    TEMP = 2000 + ((int64_t)dT * sensorCoeffs[6]) / 8388608LL;

    // *** Commented out debug prints ***
    // Serial.print("dT (Temperature Difference): ");
    // Serial.println(dT);
    // Serial.print("TEMP (Calculated Temp in 0.01°C): ");
    // Serial.println(TEMP);

    // *** More debug prints you can remove or keep
    // Serial.print("Sensor Coeff C1: ");
    // Serial.println(sensorCoeffs[1]);
    // Serial.print("Sensor Coeff C2: ");
    // Serial.println(sensorCoeffs[2]);
    // Serial.print("Sensor Coeff C3: ");
    // Serial.println(sensorCoeffs[3]);
    // Serial.print("Sensor Coeff C4: ");
    // Serial.println(sensorCoeffs[4]);

    // Compute offset and sensitivity
    Offset = (double)sensorCoeffs[2] * 131072.0 + ((double)sensorCoeffs[4] * (double)dT) / 64.0;
    Sensitivity = (double)sensorCoeffs[1] * 65536.0 + ((double)sensorCoeffs[3] * (double)dT) / 128.0;

    // *** Remove these as well
    // Serial.print("Initial Offset: ");
    // Serial.println(Offset);
    // Serial.print("Initial Sensitivity: ");
    // Serial.println(Sensitivity);

    // Apply second-order temperature compensation
    if (TEMP < 2000) {
        T2 = ((uint64_t)dT * dT) / 2147483648;  
        T2 = (int32_t)T2;  
        OFF2 = (61 * ((TEMP - 2000) * (TEMP - 2000))) / 16;  
        Sens2 = 2 * ((TEMP - 2000) * (TEMP - 2000));
    } else {
        T2 = 0;
        OFF2 = 0;
        Sens2 = 0;
    }

    if (TEMP < -1500) {
        OFF2  += 20 * ((TEMP + 1500) * (TEMP + 1500));
        Sens2 += 12 * ((TEMP + 1500) * (TEMP + 1500));
    }

    // Adjust values
    TEMP      = TEMP - T2;
    Offset    = Offset - OFF2;
    Sensitivity = Sensitivity - Sens2;

    // *** More debug removal
    // Serial.print("T2 Correction: ");
    // Serial.println(T2);
    // Serial.print("OFF2 Correction: ");
    // Serial.println(OFF2);
    // Serial.print("Sens2 Correction: ");
    // Serial.println(Sens2);

    // Compute final pressure value
    double mbarInt = (((double)D1 * (double)Sensitivity) / 2097152.0 - (double)Offset) / 32768.0;
    mbar = mbarInt / 100.0;

    // *** Remove final debug
    // Serial.print("Calculated Pressure (mbar): ");
    // Serial.println(mbar);

    // Convert temperature to Celsius
    tempC = (float)TEMP / 100.0;
}

//------------------------------------------------------------------
unsigned char MS_5803::MS_5803_CRC(unsigned int n_prom[]) {
  // (No debugging needed, but left your function intact)
  unsigned char stored_crc = n_prom[7] & 0x0F;  
  unsigned int n_prom_copy[8];
  for (int i = 0; i < 8; i++) {
    n_prom_copy[i] = n_prom[i];
  }
  n_prom_copy[7] = (n_prom_copy[7] & 0xFF00);

  unsigned int n_rem = 0;
  for (int cnt = 0; cnt < 16; cnt++) {
    if (cnt % 2 == 1) {
      n_rem ^= (unsigned short)(n_prom_copy[cnt >> 1] & 0x00FF);
    } else {
      n_rem ^= (unsigned short)(n_prom_copy[cnt >> 1] >> 8);
    }
    for (int n_bit = 8; n_bit > 0; n_bit--) {
      if (n_rem & 0x8000) {
        n_rem = (n_rem << 1) ^ 0x3000;
      } else {
        n_rem <<= 1;
      }
    }
  }
  unsigned char calc_crc = (n_rem >> 12) & 0x0F;
  return calc_crc;
}

//-----------------------------------------------------------------
unsigned long MS_5803::MS_5803_ADC(char commandADC) {
    long result = 0;
    Wire.beginTransmission(MS5803_I2C_ADDRESS);
    Wire.write(CMD_ADC_CONV + commandADC);
    byte status = Wire.endTransmission();
    
    if (status != 0) {
        return 0; // Return 0 if transmission fails
    }

    switch (commandADC & 0x0F) {
        case CMD_ADC_256 : delay(1); break;
        case CMD_ADC_512 : delay(3); break;
        case CMD_ADC_1024: delay(4); break;
        case CMD_ADC_2048: delay(6); break;
        case CMD_ADC_4096: delay(10); break;
    }

    Wire.beginTransmission(MS5803_I2C_ADDRESS);
    Wire.write((byte)CMD_ADC_READ);
    status = Wire.endTransmission();
    
    if (status != 0) {
        return 0; // Return 0 if transmission fails
    }
    
    byte bytesRequested = 3;
    byte bytesReceived = Wire.requestFrom(MS5803_I2C_ADDRESS, bytesRequested);

    if (bytesReceived != bytesRequested) {
        // Clear any remaining bytes
        while (Wire.available()) {
            Wire.read();
        }
        return 0;
    }

    if (Wire.available() >= 3) {
        HighByte = Wire.read();
        MidByte  = Wire.read();
        LowByte  = Wire.read();
    } else {
        return 0;
    }

    result = ((long)HighByte << 16) + ((long)MidByte << 8) + (long)LowByte;

    // *** Comment out raw ADC debug
    // Serial.print("Raw ADC Value for command 0x");
    // Serial.print(commandADC, HEX);
    // Serial.print(": ");
    // Serial.println(result);

    return result;
}

//----------------------------------------------------------------
void MS_5803::resetSensor() {
    Wire.beginTransmission(MS5803_I2C_ADDRESS);
    Wire.write(CMD_RESET);
    Wire.endTransmission();
    delay(10);
}